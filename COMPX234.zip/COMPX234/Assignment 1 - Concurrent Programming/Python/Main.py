from Assignment1 import Assignment1

sim = Assignment1()
sim.startSimulation()