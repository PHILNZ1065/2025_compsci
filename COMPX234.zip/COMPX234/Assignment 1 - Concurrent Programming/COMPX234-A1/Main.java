public class Main {
    public static void main(String[] args) {
        Assignment1 A1 = new Assignment1();
        A1.startSimulation();
    }
}