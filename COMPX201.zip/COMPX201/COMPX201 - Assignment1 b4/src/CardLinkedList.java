public class CardLinkedList
{
    private Node head;

    // Make Node a static class so CardDraw can use it
    public static class Node {
        private Card card;
        private Node next;

        public Node(Card card) {
            this.card = card;
            this.next = null;
        }

        public Card getCard() { // Add a getter for the card
            return card;
        }

        public Node getNext() { // Add a getter for next node
            return next;
        }
    }

    // Getter method for CardDraw to access head safely
    public Node getHead() {
        return head;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public int getLength() {
        int length = 0;
        Node current = head;
        while (current != null) {
            length++;
            current = current.next;
        }
        return length;
    }

    public boolean hasCard(Card c) {
        Node current = head;
        while (current != null) {
            if (current.card.equals(c)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public Card getCardAt(int i) {
        if (i < 0 || i >= getLength()) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }

        Node current = head;
        for (int index = 0; index < i; index++) {
            current = current.next;
        }
        return current.card;
    }

    public void add(Card c) {
        Node newNode = new Node(c);
        newNode.next = head;
        head = newNode;
    }

    public void remove(Card c) {
        if (head == null) return;

        if (head.card.equals(c)) {
            head = head.next;
            return;
        }

        Node current = head;
        while (current.next != null && !current.next.card.equals(c)) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
        }
    }

    public void clear() {
        head = null; // This removes all nodes from the list
    }

    public void print() {
        Node current = head;
        while (current != null) {
            System.out.print(current.card.print());
            if (current.next != null) {
                System.out.print(", ");
            }
            current = current.next;
        }
        System.out.println();
    }
}
