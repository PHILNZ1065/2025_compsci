import java.util.*;

public class CardDraw
{
    private static final String[] SUITS = {"Clubs", "Diamonds", "Hearts", "Spades"};
    private static final int NUM_CARDS = 52;

    public static void main(String[] args) {
        // Step 1: Create a deck of 52 cards
        CardLinkedList deck = new CardLinkedList();
        createDeck(deck);

        // Step 2: Shuffle the deck and deal hands
        shuffleDeck(deck);

        // Step 3: Create 10 player hands and calculate score for each hand
        List<CardLinkedList> playerHands = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            CardLinkedList hand = new CardLinkedList();
            dealHand(deck, hand);
            playerHands.add(hand);
            calculateHandScore(hand, i + 1);
        }

        // Step 4: Determine the winning hand
        int winningPlayer = getWinningPlayer(playerHands);
        System.out.println("Winning player: " + winningPlayer);
    }

    // Step 1: Create a deck of 52 cards
    private static void createDeck(CardLinkedList deck) {
        for (String suit : SUITS) {
            for (int i = 1; i <= 13; i++) {
                Card card = new Card(i, suit);
                deck.add(card);
            }
        }
    }

    // Step 2: Shuffle the deck
    private static void shuffleDeck(CardLinkedList deck) {
        List<Card> cards = new ArrayList<>();
        CardLinkedList.Node current = deck.getHead(); // Use getHead() instead of directly accessing head

        while (current != null) {
            cards.add(current.getCard()); // Use getter method for card
            current = current.getNext();  // Use getter method for next
        }
        Collections.shuffle(cards);

        deck.clear(); // Clear the deck properly
        for (Card card : cards) {
            deck.add(card);
        }
    }

    // Step 3: Deal a hand of 5 cards to a player
    private static void dealHand(CardLinkedList deck, CardLinkedList hand) {
        for (int i = 0; i < 5; i++) {
            CardLinkedList.Node current = deck.getHead();
            if (current == null) return; // Check if the deck is empty

            Card card = current.getCard();
            deck.remove(card);  // Remove card from deck
            hand.add(card);      // Add card to player's hand
        }
    }

    // Step 4: Calculate score for each hand
    private static void calculateHandScore(CardLinkedList hand, int playerNum) {
        Map<Integer, Integer> cardCount = new HashMap<>();
        CardLinkedList.Node current = hand.getHead();

        while (current != null) {
            int cardValue = current.getCard().getNumber();
            cardCount.put(cardValue, cardCount.getOrDefault(cardValue, 0) + 1);
            current = current.getNext();
        }

        int totalScore = calculateScore(cardCount);

        System.out.println("Player " + playerNum + "'s hand: ");
        hand.print();
        System.out.println("Player " + playerNum + " score: " + totalScore);
    }

    // Step 5: Determine the winner
    private static int getWinningPlayer(List<CardLinkedList> playerHands) {
        int winningPlayer = -1;
        int maxscore = 0;
        for (int i = 0; i < playerHands.size(); i++) {
            int handScore = calculateScoreForHand(playerHands.get(i));
            if (handScore > maxscore) {
                maxscore = handScore;
                winningPlayer = i + 1;
            }
        }
        return winningPlayer;
    }

    // Helper method to calculate total score for a hand
    private static int calculateScoreForHand(CardLinkedList hand) {
        Map<Integer, Integer> cardCount = new HashMap<>();
        CardLinkedList.Node current = hand.getHead();

        while (current != null) {
            int cardValue = current.getCard().getNumber();
            cardCount.put(cardValue, cardCount.getOrDefault(cardValue, 0) + 1);
            current = current.getNext();
        }

        return calculateScore(cardCount);
    }

    // Extracted helper method to calculate score
    private static int calculateScore(Map<Integer, Integer> cardCount) {
        int totalscore = 0;
        for (Map.Entry<Integer, Integer> entry : cardCount.entrySet()) {
            int value = entry.getKey();
            int count = entry.getValue();
            switch (count) {
                case 1:
                    totalscore += value;
                    break;
                case 2:
                    totalscore += value * 10;
                    break;
                case 3:
                    totalscore += value * 100;
                    break;
                case 4:
                    totalscore += value * 1000;
                    break;
            }
        }
        return totalscore;
    }
}
