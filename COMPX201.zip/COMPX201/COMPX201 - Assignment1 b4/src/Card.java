public class Card
{
    private int number;
    private String suit;

    // Constructor to initialize card
    public Card(int number, String suit) {
        this.number = number;
        this.suit = suit;
    }

    // Getter for the card number
    public int getNumber() {
        return number;
    }

    // Getter for the card suit
    public String getSuit() {
        return suit;
    }

    // Method to print the card in a readable format
    public String print() {
        return number + " of " + suit;
    }

    // Override equals method to compare two cards
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Card card = (Card) o;
        return number == card.number && suit.equals(card.suit);
    }

    @Override
    public int hashCode() {
        return 31 * number + suit.hashCode();
    }
}
