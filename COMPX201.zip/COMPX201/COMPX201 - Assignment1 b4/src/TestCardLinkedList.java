public class TestCardLinkedList
{

    public static void main(String[] args) {
        // Create a new linked list
        CardLinkedList cardList = new CardLinkedList();

        // Create cards
        Card card1 = new Card(1, "Spades");
        Card card2 = new Card(2, "Hearts");
        Card card3 = new Card(3, "Diamonds");

        // Add cards to the list
        cardList.add(card1);
        cardList.add(card2);
        cardList.add(card3);

        // Print the list
        cardList.print();  // Should print: 3 of Diamonds, 2 of Hearts, 1 of Spades

        // Remove a card and print again
        cardList.remove(card2);
        cardList.print();  // Should print: 3 of Diamonds, 1 of Spades

        // Check if a card exists in the list
        System.out.println(cardList.hasCard(card1));  // Should print: true
        System.out.println(cardList.hasCard(card2));  // Should print: false

        // Get a card at a specific index
        System.out.println(cardList.getCardAt(0).print());  // Should print: 3 of Diamonds
    }
}
