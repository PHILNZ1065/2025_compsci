public class CardLinkedList {
    private Node head;

    // Node class to hold the card and the next node reference
    public static class Node {
        private final Card _card;
        private Node _next;

        public Node(Card card) {
            _card = card;
            _next = null;
        }

        public Card getCard() {
            return _card;
        }

        public Node getNext() {
            return _next;
        }
    }

    // Getter for the head node
    public Node getHead() {
        return head;
    }

    // Returns the length (number of cards) in the list
    public int getLength() {
        int length = 0;
        Node current = head;
        while (current != null) {
            length++;
            current = current._next;
        }
        return length;
    }

    // Checks if the list has a specific card
    public boolean hasCard(Card c) {
        Node current = head;
        while (current != null) {
            if (current._card.equals(c)) {
                return true;
            }
            current = current._next;
        }
        return false;
    }

    // Get a card at a specific index
    public Card getCardAt(int i) {
        if (i < 0 || i >= getLength()) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }

        Node current = head;
        for (int index = 0; index < i; index++) {
            current = current._next;
        }
        return current._card;
    }

    // Adds a new card to the front of the list
    public void add(Card c) {
        Node newNode = new Node(c);
        newNode._next = head;
        head = newNode;
    }

    // Removes a specific card from the list
    public void remove(Card c) {
        if (head == null) return;

        // If the card to remove is the head
        if (head._card.equals(c)) {
            head = head._next;  // Remove the head by pointing to the next node
            return;
        }

        Node current = head;
        while (current._next != null && !current._next._card.equals(c)) {
            current = current._next; // Traverse the list until we find the card
        }

        // If the card was found, bypass it (remove it from the list)
        if (current._next != null) {
            current._next = current._next._next;
        }
    }

    // Clears the entire list (removes all cards)
    public void clear() {
        head = null;
    }

    // Prints the cards in the list
    public void print() {
        Node current = head;
        while (current != null) {
            System.out.print(current._card.print());
            if (current._next != null) {
                System.out.print(", ");
            }
            current = current._next;
        }
        System.out.println();
    }
}
