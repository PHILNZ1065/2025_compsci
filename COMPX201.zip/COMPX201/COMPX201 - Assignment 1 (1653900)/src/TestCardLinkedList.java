public class TestCardLinkedList
{
    public static void main(String[] args) {
        //Creates a new linked list
        CardLinkedList cardList = new CardLinkedList();

        ///create cards
        Card card1 = new Card(1, "Spades");
        Card card2 = new Card(2, "Hearts");
        Card card3 = new Card(3, "Diamonds");

        //add cards to the list
        cardList.add(card1);
        cardList.add(card2);
        cardList.add(card3);

        //prints list
        cardList.print();

        ///Remove the cards the print again
        cardList.remove(card2);
        cardList.print();

        //Checks if a card exists in the list
        System.out.println(cardList.hasCard(card1));
        System.out.println(cardList.hasCard(card2));

        //Get a card at a specific index
        System.out.println(cardList.getCardAt(0).print());
    }
}
