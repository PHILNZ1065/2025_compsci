public class Card
{
   //###########Instance variables
    private final int _number;
    private final String _suit;

    //Constructor
    public Card(int number, String suit) {
        _number = number;
        _suit = suit;
    }

    //#######GETTER
    public int getNumber() {
        return _number;
    }


    //#########Method to return a string representation of the card in a readable format

    public String print() {
        return _number + " of " + _suit;
    }

    //Override equals method to compare two cards
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Card card = (Card) o;
        return _number == card._number && _suit.equals(card._suit);
    }

    @Override
    public int hashCode() {
        return 31 * _number + _suit.hashCode();
    }
}
