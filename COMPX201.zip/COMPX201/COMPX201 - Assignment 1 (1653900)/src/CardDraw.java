import java.util.*;

public class CardDraw {
    ///Array of suits for the deck of cards
    private static final String[] SUITS = {"Clubs", "Diamonds", "Hearts", "Spades"};

    public static void main(String[] args) {
        //Creates a deck of 52 cards
        CardLinkedList deck = new CardLinkedList();
        createDeck(deck);

        ///Shuffles the deck
        shuffleDeck(deck);

        //Creates 10 player hands & calculate score
        List<CardLinkedList> playerHands = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            CardLinkedList hand = new CardLinkedList();
            dealHand(deck, hand);
            playerHands.add(hand);
            calculateHandScore(hand, i); 
        }

        //Determine the winning player based on the score
        int winningPlayer = getWinningPlayer(playerHands);
        System.out.println("Winner(s):");
        printWinningPlayer(playerHands, winningPlayer);
    }

    // Creates deck of 52 cards
    private static void createDeck(CardLinkedList deck) {
        for (String suit : SUITS) {
            for (int i = 1; i <= 13; i++) {
                Card card = new Card(i, suit);
                deck.add(card);
            }
        }
    }

    //Shuffles the deck
    private static void shuffleDeck(CardLinkedList deck) {
        List<Card> cards = new ArrayList<>();
        CardLinkedList.Node current = deck.getHead();

        while (current != null) {
            cards.add(current.getCard());
            current = current.getNext();
        }
        Collections.shuffle(cards);

        deck.clear();
        for (Card card : cards) {
            deck.add(card);
        }
    }

    ///Deals a hand of 5 cards to aa player
    private static void dealHand(CardLinkedList deck, CardLinkedList hand) {
        for (int i = 0; i < 5; i++) {
            CardLinkedList.Node current = deck.getHead();
            if (current == null) return;

            Card card = current.getCard();
            deck.remove(card);
            hand.add(card);
        }
    }

    //Calculate score for each hand
    private static void calculateHandScore(CardLinkedList hand, int playerNum) {
        int totalScore = calculateScoreForCards(hand);
        System.out.println("Player " + playerNum + " hand: ");
        hand.print();
        System.out.println("Player " + playerNum + " score: " + totalScore);
    }

    // Determine the winner
    private static int getWinningPlayer(List<CardLinkedList> playerHands) {
        int winningPlayer = -1;
        int maxScore = 0;
        for (int i = 0; i < playerHands.size(); i++) {
            int handScore = calculateScoreForCards(playerHands.get(i));
            if (handScore > maxScore) {
                maxScore = handScore;
                winningPlayer = i;
            }
        }
        return winningPlayer;
    }

    // Print the winner(s)
    private static void printWinningPlayer(List<CardLinkedList> playerHands, int winningPlayer) {
        List<Integer> winners = new ArrayList<>();
        int maxScore = 0;
        for (int i = 0; i < playerHands.size(); i++) {
            int handScore = calculateScoreForCards(playerHands.get(i));
            if (handScore > maxScore) {
                maxScore = handScore;
                winners.clear();
                winners.add(i);
            } else if (handScore == maxScore) {
                winners.add(i);
            }
        }

        for (int winner : winners) {
            CardLinkedList winningHand = playerHands.get(winner);
            System.out.print("Player " + winner + " had the score " + maxScore + " with the hand of ");
            winningHand.print();
        }
    }

    ///helper method for counting card occurrences and determining hand score
    private static int calculateScoreForCards(CardLinkedList hand) {
        Map<Integer, Integer> cardCount = new HashMap<>();
        CardLinkedList.Node current = hand.getHead();

        while (current != null) {
            int cardValue = current.getCard().getNumber();
            cardCount.put(cardValue, cardCount.getOrDefault(cardValue, 0) + 1);
            current = current.getNext();
        }

        return calculateScore(cardCount);
    }

    // Extracted helper method to calculate score
    private static int calculateScore(Map<Integer, Integer> cardCount) {
        int totalScore = 0;
        for (Map.Entry<Integer, Integer> entry : cardCount.entrySet()) {
            int value = entry.getKey();
            int count = entry.getValue();
            switch (count) {
                case 1:
                    totalScore += value;
                    break;
                case 2:
                    totalScore += value * 10;
                    break;
                case 3:
                    totalScore += value * 100;
                    break;
                case 4:
                    totalScore += value * 1000;
                    break;
            }
        }
        return totalScore;
    }
}
